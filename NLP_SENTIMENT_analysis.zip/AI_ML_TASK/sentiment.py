# -*- coding: utf-8 -*-
"""
Created on Sat Aug 28 22:43:22 2021

@author: intel
"""


def map_sentiment(x):
    from textblob import TextBlob
    from autocorrect import Speller
    spell = Speller(lang="en")
    sentiment = []
    x = str(x)
    x = " ".join([spell(w) for w in x.split(" ")])
    x = x.lower()
    if TextBlob(str(x)).sentiment.polarity > 0 :
        sentiment.append("positive")
    elif TextBlob(str(x)).sentiment.polarity < 0:
        sentiment.append("negative")
    else:
        sentiment.append("neutral")
    return " ".join(sentiment)



